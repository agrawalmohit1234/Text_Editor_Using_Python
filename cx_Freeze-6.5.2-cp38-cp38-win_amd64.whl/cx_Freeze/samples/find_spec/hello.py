#!/usr/bin/env python


import dummypackage.dummymodule

print("Hi, I'm a program.")

raise Exception("This exception is fine.")
