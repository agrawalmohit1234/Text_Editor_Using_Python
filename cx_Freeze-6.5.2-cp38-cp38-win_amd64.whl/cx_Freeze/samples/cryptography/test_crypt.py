from cryptography.fernet import Fernet

print("Hello cryptography", Fernet)
