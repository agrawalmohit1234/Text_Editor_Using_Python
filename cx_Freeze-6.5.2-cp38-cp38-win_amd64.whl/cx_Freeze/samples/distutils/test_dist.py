from distutils import dist, sysconfig

print("Hello distutils")
print(dist)
print(sysconfig)
